function [plt] = makePlots(r, u, a, f_x, f_y, f_theta)

plt = 1;

end