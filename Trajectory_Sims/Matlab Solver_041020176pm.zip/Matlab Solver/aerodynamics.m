function [Fdrag, Flift] = aerodynamics(rocket, r, u, a, aoa)

Fdrag = NaN;
Flift = NaN;

end